package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EvaluationController {
    @GetMapping("/pages/evaluation/manage")
    public String handleevaluationhome() {
        return "/pages/evaluation/manage_evaluation";
    }
    @GetMapping("/pages/evaluation/add")
    public String handleevaluationadd() {
        return "/pages/evaluation/add_evaluation";
    }

}
