package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ClassController {
    @GetMapping("/pages/class/manage")
    public String handleclasshome() {
        return "/pages/class/manage_class";
    }
    @GetMapping("/pages/class/add")
    public String handleclassadd() {
        return "/pages/class/add_class";
    }
}
