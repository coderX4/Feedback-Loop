package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class AcademicController {
    @GetMapping("/pages/academic/manage")
    public String handleacademichome() {
        return "/pages/academic/manage_academic";
    }
    @GetMapping("/pages/academic/add")
    public String handleacademicadd() {
        return "/pages/academic/add_academic";
    }
}
