package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class FacultyController {
    @GetMapping("/pages/faculty/manage")
    public String handlefacultyhome() {
        return "/pages/faculty/manage_faculty";
    }
    @GetMapping("/pages/faculty/add")
    public String handlefacultyadd() {
        return "/pages/faculty/add_faculty";
    }
}
