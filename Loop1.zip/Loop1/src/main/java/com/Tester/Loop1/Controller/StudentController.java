package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class StudentController {
    @GetMapping("/pages/student/manage")
    public String handlestudenthome() {
        return "/pages/student/manage_student";
    }
    @GetMapping("/pages/student/add")
    public String handlestudentadd() {
        return "/pages/student/add_student";
    }
}
