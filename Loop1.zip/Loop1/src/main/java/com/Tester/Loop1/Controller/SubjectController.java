package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class SubjectController {

    @GetMapping("/pages/subject/manage")
    public String handlesubjecthome() {
        return "/pages/subject/manage_subjects";
    }
    @GetMapping("/pages/subject/add")
    public String handlesubjectadd() {
        return "/pages/subject/add_subjects";
    }
}
