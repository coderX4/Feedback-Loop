package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ReportController {
    @GetMapping("/pages/report/manage")
    public String handlereporthome() {
        return "/pages/report/manage_report";
    }
    @GetMapping("/pages/report/list")
    public String handlereportlist() {
        return "/pages/report/list_report";
    }
}
