package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class QuestionController {
    @GetMapping("/pages/question/manage")
    public String handlequestionhome() {
        return "/pages/question/manage_question";
    }
    @GetMapping("/pages/question/add")
    public String handlequestionadd() {
        return "/pages/question/add_question";
    }
}
