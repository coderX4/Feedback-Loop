package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CriteriaController {
    @GetMapping("/pages/criteria/manage")
    public String handlecriteriahome() {
        return "/pages/criteria/manage_criteria";
    }
    @GetMapping("/pages/criteria/add")
    public String handlecriteriaadd() {
        return "/pages/criteria/add_criteria";
    }
}
