package com.Tester.Loop1.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController {

  @GetMapping("/home")
  public String handleWelcome() {
    return "home";
  }

  @GetMapping("/admin/home")
  public String handleAdminHome() {
    return "/pages/landing_page";
  }

  @GetMapping("/user/home")
  public String handleUserHome() {
    return "/pages/student_landing_page";
  }

  @GetMapping("/login")
  public String handleLogin() {
    return "auth-login";
  }

  @GetMapping("/pages/home")
  public String handleHome() {
    return "/pages/landing_page";
  }

}
